import { Certificate } from '../common'

const Template = Certificate({})

export default Template
