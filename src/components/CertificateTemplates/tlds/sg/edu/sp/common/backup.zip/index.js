export * from './images'
export { default as Certificate } from './certificate'

export const approvedAddresses = [
  '0xa5d801265D29A6F1015a641BfC0e39Ee3dA2AC76',
  '0xD939B3934fB024517296e0b9091E72F222F81c1E',
  '0xBd5B320ff892B5afc400b5FF2A0CC9a56e89562b',
  '0xc36484efa1544c32ffed2e80a1ea9f0dfc517495',
  '0x866Fb78aC3c87019aBff9FB566acfF66F75Cfa46',
  '0x9B12B5C3fdA927ba4e9E707e2BA0b8405cAFB394'
]
